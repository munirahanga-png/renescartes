"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import {
  Calendar,
  MapPin,
  Clock,
  Users,
  ArrowRight,
  Search,
  BookOpen,
  Award,
  Briefcase,
  Building,
  Monitor,
  Globe,
  Target,
  Lightbulb,
  BarChart3,
  Shield,
  ChevronRight,
  GraduationCap,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const categories = [
  "All Courses",
  "HSEQ & Risk Management",
  "Project Management",
  "Energy & Environment",
  "Leadership & Strategy",
  "Digital & BIM",
  "Education & Research",
  "Data & Business Intelligence",
  "HR & Talent Development",
  "Governance & Compliance",
];

const courses = [
  {
    id: 1,
    title: "Health, Safety, Environment & Quality (HSEQ) Management",
    category: "HSEQ & Risk Management",
    description:
      "Comprehensive training on integrated HSEQ management systems for oil & gas, construction, and energy sectors. Covers ISO 45001, ISO 14001, and ISO 9001 standards.",
    duration: "5 Days",
    format: "Classroom & Virtual",
    image:
      "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=2070&auto=format&fit=crop",
    sessions: [
      { city: "Abuja, Nigeria", date: "17 - 21 March 2025" },
      { city: "London, UK", date: "14 - 18 April 2025" },
    ],
    featured: true,
  },
  {
    id: 2,
    title: "Enterprise Risk Management (ERM) Masterclass",
    category: "HSEQ & Risk Management",
    description:
      "Advanced risk identification, assessment, and mitigation strategies for organisations operating in complex, high-risk environments.",
    duration: "4 Days",
    format: "Classroom & Virtual",
    image:
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2070&auto=format&fit=crop",
    sessions: [
      { city: "Abuja, Nigeria", date: "7 - 10 April 2025" },
      { city: "Coventry, UK", date: "12 - 15 May 2025" },
    ],
    featured: true,
  },
  {
    id: 3,
    title: "Project Management Professional (PMP) Preparation",
    category: "Project Management",
    description:
      "Intensive preparation for the PMP certification exam, with focus on project planning, execution, monitoring, and stakeholder management.",
    duration: "5 Days",
    format: "Classroom & Virtual",
    image:
      "https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop",
    sessions: [
      { city: "Abuja, Nigeria", date: "24 - 28 March 2025" },
      { city: "London, UK", date: "5 - 9 May 2025" },
    ],
    featured: false,
  },
  {
    id: 4,
    title: "Environmental Impact Assessment (EIA) & Audit",
    category: "Energy & Environment",
    description:
      "Practical training on conducting environmental impact assessments, environmental auditing, and compliance with national and international environmental regulations.",
    duration: "4 Days",
    format: "Classroom",
    image:
      "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?q=80&w=2070&auto=format&fit=crop",
    sessions: [{ city: "Abuja, Nigeria", date: "14 - 17 April 2025" }],
    featured: false,
  },
  {
    id: 5,
    title: "BIM Level 2 Implementation & Digital Engineering",
    category: "Digital & BIM",
    description:
      "Hands-on training on Building Information Modelling (BIM) implementation strategies, digital twin technologies, and ISO 19650 compliance for construction and infrastructure projects.",
    duration: "5 Days",
    format: "Classroom & Virtual",
    image:
      "https://images.unsplash.com/photo-1581092160562-40aa08e78837?q=80&w=2070&auto=format&fit=crop",
    sessions: [
      { city: "London, UK", date: "21 - 25 April 2025" },
      { city: "Abuja, Nigeria", date: "19 - 23 May 2025" },
    ],
    featured: true,
  },
  {
    id: 6,
    title: "Strategic Leadership & Organisational Transformation",
    category: "Leadership & Strategy",
    description:
      "Designed for senior managers and executives, this programme covers strategic planning, change management, and organisational restructuring for improved performance.",
    duration: "3 Days",
    format: "Classroom & Virtual",
    image:
      "https://images.unsplash.com/photo-1557804506-669a67965ba0?q=80&w=2070&auto=format&fit=crop",
    sessions: [{ city: "Abuja, Nigeria", date: "7 - 9 May 2025" }],
    featured: false,
  },
  {
    id: 7,
    title: "Renewable Energy Systems: Feasibility & Implementation",
    category: "Energy & Environment",
    description:
      "Comprehensive training on solar, wind, and hybrid energy system design, feasibility studies, and project financing for rural and industrial electrification.",
    duration: "5 Days",
    format: "Classroom",
    image:
      "https://images.unsplash.com/photo-1466611653911-9548152ac92b?q=80&w=2070&auto=format&fit=crop",
    sessions: [
      { city: "Abuja, Nigeria", date: "2 - 6 June 2025" },
      { city: "Coventry, UK", date: "23 - 27 June 2025" },
    ],
    featured: false,
  },
  {
    id: 8,
    title: "Higher Education Management & International Recruitment",
    category: "Education & Research",
    description:
      "Training for education administrators on global student recruitment strategies, academic-industry collaboration, and institutional capacity building.",
    duration: "3 Days",
    format: "Virtual",
    image:
      "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?q=80&w=2070&auto=format&fit=crop",
    sessions: [{ city: "Virtual / Online", date: "16 - 18 June 2025" }],
    featured: false,
  },
  {
    id: 9,
    title: "Leadership & Business Management",
    category: "Leadership & Strategy",
    description:
      "Develop skills to lead teams and drive organisational success. Covers strategic decision-making, leadership styles, and business management best practices.",
    duration: "5 Days",
    format: "Classroom & Virtual",
    image:
      "https://images.unsplash.com/photo-1519389950473-47ba0277781c?q=80&w=2070&auto=format&fit=crop",
    sessions: [
      { city: "London, UK", date: "10 - 14 March 2025" },
      { city: "Lagos, Nigeria", date: "7 - 11 April 2025" },
    ],
    featured: false,
  },
  {
    id: 10,
    title: "Human Resource Management & Talent Development",
    category: "HR & Talent Development",
    description:
      "Master the art of talent acquisition, employee development, performance management, and HR analytics for modern organisations.",
    duration: "5 Days",
    format: "Classroom & Virtual",
    image:
      "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?q=80&w=2070&auto=format&fit=crop",
    sessions: [
      { city: "Abuja, Nigeria", date: "24 - 28 March 2025" },
      { city: "Manchester, UK", date: "28 April - 2 May 2025" },
    ],
    featured: false,
  },
  {
    id: 11,
    title: "Data Analytics & Business Intelligence",
    category: "Data & Business Intelligence",
    description:
      "Turn data into actionable insights for business growth. Covers data visualisation, statistical analysis, and BI tools for informed decision-making.",
    duration: "5 Days",
    format: "Classroom & Virtual",
    image:
      "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop",
    sessions: [
      { city: "London, UK", date: "17 - 21 March 2025" },
      { city: "Abuja, Nigeria", date: "12 - 16 May 2025" },
    ],
    featured: false,
  },
  {
    id: 12,
    title: "Governance, Risk & Compliance (GRC)",
    category: "Governance & Compliance",
    description:
      "Comprehensive training for regulatory compliance professionals covering corporate governance frameworks, risk management, and compliance standards.",
    duration: "4 Days",
    format: "Classroom & Virtual",
    image:
      "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?q=80&w=2070&auto=format&fit=crop",
    sessions: [
      { city: "Abuja, Nigeria", date: "31 March - 3 April 2025" },
      { city: "London, UK", date: "19 - 22 May 2025" },
    ],
    featured: false,
  },
  {
    id: 13,
    title: "HR Analytics & Data-Driven People Management",
    category: "HR & Talent Development",
    description:
      "Use data to make informed decisions about human resources. Covers workforce analytics, predictive modelling, and people metrics dashboards.",
    duration: "3 Days",
    format: "Classroom & Virtual",
    image:
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2070&auto=format&fit=crop",
    sessions: [
      { city: "London, UK", date: "14 - 16 April 2025" },
      { city: "Lagos, Nigeria", date: "5 - 7 May 2025" },
    ],
    featured: false,
  },
  {
    id: 14,
    title: "Data Visualisation & Reporting",
    category: "Data & Business Intelligence",
    description:
      "Create compelling visual representations of complex data using modern tools and techniques. Covers Power BI, Tableau, and advanced charting.",
    duration: "3 Days",
    format: "Virtual",
    image:
      "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop",
    sessions: [{ city: "Virtual / Online", date: "21 - 23 April 2025" }],
    featured: false,
  },
];

const courseSpecialisations = [
  "Banking, Insurance & Financial Services",
  "Communication & Writing Skills",
  "Customer Service",
  "Data Analytics & Business Intelligence",
  "Digital Transformation & Innovation",
  "Energy Transition & Renewable Energy",
  "Financial Management & Accounting",
  "Governance, Risk & Compliance",
  "Health, Safety & Environment",
  "Human Resource Management & Talent Development",
  "Information Technology & Digital Systems",
  "IT Management & Cyber Security",
  "Leadership & Business Management",
  "Legal & Contracts Management",
  "Maintenance & Engineering",
  "Office Administration & Executive Support",
  "Oil & Gas Technology",
  "Operational Auditing & Quality Assurance",
  "Personal Effectiveness & Self Development",
  "Project & Program Management",
  "Public Relations",
  "Risk & Crisis Management",
  "Sales & Marketing",
  "Security Operations & Risk Protection",
  "Strategy & Strategic Planning",
  "Supply Chain Management & Procurement",
];

const trainingFormats = [
  {
    title: "Classroom Training",
    description:
      "Expert-led sessions at premium venues across the UK and Nigeria",
    icon: Building,
  },
  {
    title: "Online Training",
    description:
      "Flexible digital learning delivered at a pace to suit your requirements",
    icon: Monitor,
  },
  {
    title: "In-House Training",
    description:
      "Customised programs delivered at your organisation's facilities",
    icon: Users,
  },
];

const venues = [
  { city: "London", country: "UK" },
  { city: "Lagos", country: "Nigeria" },
  { city: "Abuja", country: "Nigeria" },
  { city: "Manchester", country: "UK" },
  { city: "Port Harcourt", country: "Nigeria" },
  { city: "Edinburgh", country: "UK" },
];

const whyChooseUs = [
  {
    title: "Industry Expertise",
    description:
      "Our trainers bring decades of real-world experience from energy, infrastructure, and corporate sectors.",
    icon: Award,
  },
  {
    title: "Global Reach",
    description:
      "Training programs delivered across the UK and Nigeria with consistent quality standards.",
    icon: Globe,
  },
  {
    title: "Tailored Solutions",
    description:
      "Customised curricula designed to address your organisation's specific challenges and goals.",
    icon: Target,
  },
  {
    title: "Practical Approach",
    description:
      "Hands-on learning methodologies that translate directly into workplace performance.",
    icon: Lightbulb,
  },
];

export default function CoursesTrainingPage() {
  const [activeCategory, setActiveCategory] = useState("All Courses");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCourses = courses.filter((course) => {
    const matchesCategory =
      activeCategory === "All Courses" || course.category === activeCategory;
    const matchesSearch =
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const featuredCourses = courses.filter((c) => c.featured);

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="bg-[#123057] pt-10 pb-10 md:pb-14 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="https://images.unsplash.com/photo-1524178232363-1fb2b075b655?q=80&w=2070&auto=format&fit=crop"
            alt="Professional Training & Capacity Building"
            fill
            className="object-cover opacity-20"
          />
        </div>
        <div className="corporate-container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <p className="section-title text-[#E1702C]">
              Professional Development
            </p>
            <h1 className="text-4xl md:text-6xl text-white font-bold leading-tight mb-8 uppercase tracking-tight">
              Courses & <br />
              <span className="text-white/60">Training</span>
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed font-light">
              Build capacity through our scheduled professional training
              programmes. Delivered by industry experts with real-world
              experience across the UK and Nigeria.
            </p>
          </motion.div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
            {[
              { value: "20+", label: "Courses Available", icon: BookOpen },
              { value: "500+", label: "Professionals Trained", icon: Users },
              { value: "2", label: "Countries", icon: MapPin },
              { value: "CPD", label: "Accredited Programmes", icon: Award },
            ].map((stat) => (
              <div key={stat.label} className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 flex items-center justify-center">
                  <stat.icon className="text-[#E1702C]" size={22} />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                  <p className="text-[10px] uppercase tracking-widest text-gray-400 font-bold">
                    {stat.label}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="absolute top-0 right-0 w-1/2 h-full bg-white/5 skew-x-12 translate-x-1/4" />
      </section>

      {/* Why Choose Us */}
      <section className="py-8 md:py-12 bg-white">
        <div className="corporate-container">
          <div className="text-center mb-12">
            <p className="section-title">Why Choose Us</p>
            <h2 className="section-heading mb-0">
              The Ren&eacute;s-Cartes Advantage
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyChooseUs.map((item, idx) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="text-center group"
              >
                <div className="w-16 h-16 bg-gray-50 group-hover:bg-[#123057] rounded-2xl flex items-center justify-center mx-auto mb-4 text-[#E1702C] group-hover:text-white transition-all duration-300 shadow-sm group-hover:shadow-xl group-hover:-translate-y-2">
                  <item.icon size={32} strokeWidth={1.5} />
                </div>
                <h3 className="text-lg font-bold text-[#123057] mb-2">
                  {item.title}
                </h3>
                <p className="text-gray-600 text-sm">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Upcoming Courses */}
      <section className="py-8 md:py-12 bg-gray-50 border-y border-gray-100">
        <div className="corporate-container">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-6">
            <div>
              <p className="section-title">Featured Programmes</p>
              <h2 className="section-heading mb-0">
                Upcoming Scheduled Courses
              </h2>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {featuredCourses.map((course, idx) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group flex flex-col bg-white border border-gray-200 hover:border-[#123057] hover:shadow-xl transition-all duration-300 overflow-hidden"
              >
                <div className="relative aspect-video overflow-hidden">
                  <Image
                    src={course.image}
                    alt={course.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="inline-block px-3 py-1 text-[10px] font-bold uppercase tracking-widest bg-[#E1702C] text-white">
                      Featured
                    </span>
                  </div>
                </div>
                <div className="flex flex-col flex-grow p-6 md:p-8">
                  <span className="text-[10px] font-bold text-[#E1702C] uppercase tracking-widest mb-3">
                    {course.category}
                  </span>
                  <h3 className="text-lg font-bold text-[#123057] uppercase tracking-tight mb-3 leading-snug">
                    {course.title}
                  </h3>
                  <p className="text-sm text-gray-600 leading-relaxed mb-6 flex-grow font-light">
                    {course.description}
                  </p>

                  <div className="space-y-3 mb-6 pt-4 border-t border-gray-100">
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Clock size={14} className="text-[#123057]" />
                      <span className="font-bold text-xs uppercase tracking-wide">
                        {course.duration}
                      </span>
                      <span className="mx-2 text-gray-300">|</span>
                      <span className="text-xs">{course.format}</span>
                    </div>
                    {course.sessions.map((session, sIdx) => (
                      <div key={sIdx} className="flex items-center gap-2 text-sm">
                        <Calendar size={14} className="text-[#E1702C]" />
                        <span className="text-gray-700 text-xs">
                          <span className="font-bold">{session.city}</span>{" "}
                          &mdash; {session.date}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-3">
                    <Button
                      asChild
                      className="flex-1 bg-[#123057] hover:bg-[#0A1D36] text-white h-auto py-3 text-[10px] font-bold uppercase tracking-widest"
                    >
                      <Link href="/engage">Register Now</Link>
                    </Button>
                    <Button
                      asChild
                      variant="outline"
                      className="border-[#123057] text-[#123057] hover:bg-[#123057] hover:text-white h-auto py-3 text-[10px] font-bold uppercase tracking-widest"
                    >
                      <Link href="/contact">Enquire</Link>
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Full Course Catalogue */}
      <section
        id="courses"
        className="py-8 md:py-12 bg-white"
      >
        <div className="corporate-container">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <p className="section-title">Course Catalogue</p>
            <h2 className="section-heading">
              Browse All Training Programmes
            </h2>
            <p className="text-gray-600 text-base font-light">
              Explore our full range of professional development programmes
              designed to build capacity across key sectors and disciplines.
            </p>
          </div>

          {/* Search & Filter */}
          <div className="flex flex-col md:flex-row gap-4 mb-10">
            <div className="relative flex-1">
              <Search
                size={18}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"
              />
              <input
                type="text"
                placeholder="Search courses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 border border-gray-200 bg-white text-sm font-medium focus:outline-none focus:border-[#123057] transition-colors"
              />
            </div>
          </div>

          {/* Category Filters */}
          <div className="flex flex-wrap gap-2 mb-10">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2.5 text-[10px] font-bold uppercase tracking-widest transition-all ${
                  activeCategory === cat
                    ? "bg-[#123057] text-white"
                    : "bg-white border border-gray-200 text-gray-600 hover:border-[#123057] hover:text-[#123057]"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Course Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredCourses.map((course, idx) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.05 }}
                className="flex flex-col sm:flex-row bg-white border border-gray-200 hover:border-[#123057] hover:shadow-lg transition-all duration-300 overflow-hidden group"
              >
                <div className="relative w-full sm:w-48 aspect-video sm:aspect-auto shrink-0 overflow-hidden">
                  <Image
                    src={course.image}
                    alt={course.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="flex flex-col flex-grow p-6">
                  <span className="text-[9px] font-bold text-[#E1702C] uppercase tracking-widest mb-2">
                    {course.category}
                  </span>
                  <h4 className="text-base font-bold text-[#123057] uppercase tracking-tight mb-2 leading-snug">
                    {course.title}
                  </h4>
                  <p className="text-xs text-gray-500 leading-relaxed mb-4 flex-grow line-clamp-2 font-light">
                    {course.description}
                  </p>
                  <div className="flex flex-wrap items-center gap-3 text-xs text-gray-500 mb-4">
                    <div className="flex items-center gap-1">
                      <Clock size={12} className="text-[#123057]" />
                      <span className="font-bold">{course.duration}</span>
                    </div>
                    <span className="text-gray-300">|</span>
                    <span>{course.format}</span>
                    <span className="text-gray-300">|</span>
                    <div className="flex items-center gap-1">
                      <MapPin size={12} className="text-[#E1702C]" />
                      <span>{course.sessions[0].city}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs text-gray-400">
                      Next:{" "}
                      <span className="font-bold text-[#123057]">
                        {course.sessions[0].date}
                      </span>
                    </span>
                    <Link
                      href="/engage"
                      className="inline-flex items-center text-[10px] font-bold text-[#E1702C] uppercase tracking-widest hover:text-[#123057] transition-colors ml-auto"
                    >
                      Register <ArrowRight size={12} className="ml-1" />
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {filteredCourses.length === 0 && (
            <div className="text-center py-16">
              <p className="text-gray-500 text-lg">
                No courses found matching your criteria.
              </p>
              <button
                onClick={() => {
                  setActiveCategory("All Courses");
                  setSearchQuery("");
                }}
                className="mt-4 text-[#E1702C] font-bold text-sm uppercase tracking-widest hover:underline"
              >
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Training Formats */}
      <section className="py-8 md:py-12 bg-[#123057]">
        <div className="corporate-container">
          <div className="text-center mb-12">
            <p className="section-title text-[#E1702C]">Delivery Options</p>
            <h2 className="section-heading text-white mb-2">
              Flexible Training Formats
            </h2>
            <p className="text-gray-300 font-light">
              Designed to suit your organisational requirements
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {trainingFormats.map((format, idx) => (
              <motion.div
                key={format.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white/10 backdrop-blur-sm p-8 text-center hover:bg-white/20 transition-all duration-300"
              >
                <div className="w-16 h-16 bg-[#E1702C] rounded-full flex items-center justify-center mx-auto mb-6">
                  <format.icon size={32} className="text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">
                  {format.title}
                </h3>
                <p className="text-gray-300 text-sm">{format.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Course Specialisations */}
      <section className="py-8 md:py-12 bg-gray-50">
        <div className="corporate-container">
          <div className="text-center mb-12">
            <p className="section-title">Specialisations</p>
            <h2 className="section-heading mb-2">
              Explore Our Course Categories
            </h2>
            <p className="text-gray-600 font-light">
              Find the right training for your team
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {courseSpecialisations.map((category, idx) => (
              <motion.div
                key={category}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.02 }}
                className="p-4 bg-white text-left text-sm text-gray-700 hover:bg-[#123057] hover:text-white transition-all duration-300 border border-gray-100 shadow-sm cursor-pointer"
              >
                {category}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Training Venues */}
      <section className="py-8 md:py-12 bg-white">
        <div className="corporate-container">
          <div className="text-center mb-12">
            <p className="section-title">Locations</p>
            <h2 className="section-heading mb-2">Training Venues</h2>
            <p className="text-gray-600 font-light">
              We deliver training across the UK and Nigeria
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {venues.map((venue, idx) => (
              <motion.div
                key={venue.city}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-gray-50 p-6 text-center hover:bg-[#123057] group transition-all duration-300 cursor-pointer"
              >
                <div className="w-12 h-12 bg-[#E1702C]/10 group-hover:bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3 transition-colors">
                  <Globe
                    size={24}
                    className="text-[#E1702C] group-hover:text-white transition-colors"
                  />
                </div>
                <h3 className="text-[#123057] group-hover:text-white font-bold text-lg transition-colors">
                  {venue.city}
                </h3>
                <p className="text-gray-500 group-hover:text-gray-300 text-sm transition-colors">
                  {venue.country}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* In-House / Bespoke Training */}
      <section className="py-8 md:py-12 bg-gray-50 border-y border-gray-100">
        <div className="corporate-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <p className="section-title">Bespoke Solutions</p>
              <h2 className="section-heading">
                In-House & Customised Training
              </h2>
              <div className="space-y-6 text-gray-700 leading-relaxed text-base md:text-lg font-light">
                <p>
                  Beyond our scheduled programmes, Ren&eacute;s-Cartes delivers
                  tailored in-house training solutions designed to address the
                  specific capacity building needs of your organisation.
                </p>
                <p>
                  Our bespoke programmes are developed in close consultation with
                  your team to ensure maximum relevance and impact, drawing on
                  our deep expertise across multiple sectors.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8">
                {[
                  "Customised Curriculum Design",
                  "On-Site & Virtual Delivery",
                  "Post-Training Assessment",
                  "CPD Certification Support",
                ].map((item) => (
                  <div key={item} className="flex items-center gap-3">
                    <div className="w-1.5 h-1.5 bg-[#E1702C] rounded-full" />
                    <span className="text-xs font-bold text-[#123057] uppercase tracking-wide">
                      {item}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-10">
                <Button
                  asChild
                  className="bg-[#E1702C] hover:bg-[#C95E1F] text-white px-10 py-5 h-auto text-xs font-bold uppercase tracking-widest"
                >
                  <Link href="/contact">Request Bespoke Training</Link>
                </Button>
              </div>
            </div>
            <div className="relative aspect-video shadow-2xl overflow-hidden group">
              <Image
                src="https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=2070&auto=format&fit=crop"
                alt="In-House Corporate Training"
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-1000"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-10 md:py-14 bg-[#E1702C] relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black/10 to-transparent pointer-events-none" />
        <div className="corporate-container relative z-10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-10">
            <div className="text-white max-w-xl text-center lg:text-left">
              <h2 className="text-2xl md:text-4xl font-bold uppercase tracking-tight mb-4">
                Ready to Enhance Your Team&apos;s Capabilities?
              </h2>
              <p className="text-white/80 text-base font-light">
                Contact us to discuss group bookings, bespoke programmes, or to
                receive our full training calendar.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                asChild
                className="bg-[#123057] hover:bg-[#0A1D36] text-white px-10 py-5 h-auto text-base font-bold uppercase tracking-widest rounded-full shadow-[0_20px_40px_rgba(0,0,0,0.2)] transition-all duration-300 hover:-translate-y-1"
              >
                <Link href="/engage">Engage Our Experts</Link>
              </Button>
              <Button
                asChild
                variant="outline"
                className="border-white/40 text-white hover:bg-white hover:text-[#E1702C] px-10 py-5 h-auto text-base font-bold uppercase tracking-widest rounded-full transition-all duration-300 hover:-translate-y-1 bg-transparent border-2"
              >
                <Link href="/contact">Download Calendar</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
