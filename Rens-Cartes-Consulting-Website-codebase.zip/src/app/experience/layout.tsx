import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Our Experience | Renés-Cartes Energy & Management Consulting",
  description: "A record of strategic technical delivery across multiple sectors in the UK and Nigeria.",
};

export default function ExperienceLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
