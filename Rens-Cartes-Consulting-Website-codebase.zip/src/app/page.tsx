"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import {
  ArrowRight,
  ShieldCheck,
  Settings,
  Cpu,
  Wind,
  Globe,
  Database,
  Briefcase,
  Layers,
  Activity,
  Lightbulb,
  GraduationCap } from
"lucide-react";
import { Button } from "@/components/ui/button";

const services = [
{
  title: "Energy & Environment",
  description: "Strategic frameworks for sustainable energy transitions and rigorous environmental compliance.",
  icon: Wind,
  href: "/services/energy-environment"
},
{
  title: "BIM & Digital Engineering",
  description: "Advanced digital twin integration and BIM protocols for high-performance infrastructure delivery.",
  icon: Cpu,
  href: "/services/bim-digital"
},
{
  title: "Project Management",
  description: "Technical oversight and delivery excellence for complex, multidisciplinary capital projects.",
  icon: Settings,
  href: "/services/project-management"
},
{
  title: "Education Consultancy",
  description: "Innovative solutions supporting excellence in higher education and global student recruitment.",
  icon: GraduationCap,
  href: "/services/education-consultancy"
}];


const sectors = [
"Energy & Renewables",
"Oil & Gas",
"Public Infrastructure",
"Construction & Engineering",
"Education & Research",
"Telecommunications",
"Strategic Real Estate",
"Enterprise Risk"];


const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

export default function Home() {
  const [heroText, setHeroText] = useState("Renés-Cartes operates at the nexus of technology and management innovation, offering global technical expertise, local insights and strategic management excellence to deliver high-value-for-money through multi-disciplinary consultancy services across several sectors");

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] md:h-[85vh] flex items-center overflow-hidden bg-[#123057] pt-12 md:pt-16">
        <div className="absolute inset-0 z-0">
          <Image
            src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070&auto=format&fit=crop"
            alt="Strategic Technical Consultancy"
            fill
            className="object-cover"
            priority />


          <div className="absolute inset-0 bg-[#123057]/75 md:bg-gradient-to-r md:from-[#123057]/90 md:via-[#123057]/75 md:to-transparent w-full h-full" />
        </div>

        <div className="corporate-container relative z-10 !w-full !h-[639px] !max-w-full">
          <motion.div
            className="max-w-3xl text-left"
            initial="initial"
            animate="animate"
            variants={fadeIn}>

            <div className="inline-block px-3 py-1 border border-[#E1702C]/50 text-[#E1702C] text-[9px] md:text-xs font-bold uppercase tracking-[0.3em] mb-4 md:mb-6">
              International Multidisciplinary Consultancy
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-5xl text-white font-bold leading-[1.15] mb-4 md:mb-6 uppercase tracking-tight">
              Global Technical Expertise; <br />
              Local Insights; <br />
              <span className="text-white/60">Strategic Management Excellence</span>
            </h1>
            <p className="text-base md:text-lg text-gray-300 mb-8 md:mb-10 leading-relaxed font-light !w-9/12 !h-[99px] !max-w-[75%]">{heroText}</p>
            <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
              <Button asChild className="bg-gradient-to-r from-[#E1702C] to-[#C95E1F] hover:from-[#123057] hover:to-[#0e2444] text-white px-8 md:px-10 py-4 md:py-6 text-sm md:text-base rounded-full h-auto font-bold uppercase tracking-wider transition-all duration-300 shadow-[0_10px_30px_rgba(225,112,44,0.3)] hover:shadow-[0_15px_35px_rgba(225,112,44,0.4)] hover:-translate-y-1">
                <Link href="/engage">Engage Our Experts</Link>
              </Button>
              <Button variant="outline" className="bg-white/10 backdrop-blur-md border-white/40 text-white hover:bg-[#E1702C] hover:border-[#E1702C] hover:text-white px-8 md:px-10 py-4 md:py-6 text-sm md:text-base rounded-full h-auto font-bold uppercase tracking-wider border-2 transition-all duration-300 hover:-translate-y-1 shadow-lg" onClick={() => setHeroText("Renés-Cartes provides high-impact global technical expertise, with local insights and strategic management excellence, delivering solutions designed to improve organisational performance and resilience in a complex global environment")}>
                Our Capabilities
              </Button>
            </div>
          </motion.div>
        </div>
        
        {/* Abstract Geometry Overlay */}
        <div className="absolute right-0 top-0 w-1/2 h-full opacity-[0.03] pointer-events-none hidden md:block">
          <svg viewBox="0 0 100 100" className="w-full h-full text-white fill-current">
            <path d="M0 0 L100 0 L100 100 Z" />
          </svg>
        </div>
      </section>

      {/* Authority Statement */}
      <section className="py-8 md:py-12 bg-white">
        <div className="corporate-container">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-16 items-center">
            <div className="lg:col-span-5 order-2 lg:order-1">
              <p className="section-title">Who We Are</p>
              <h2 className="section-heading text-2xl md:text-4xl lg:text-5xl">
                Bridging Technical Precision with Strategic Vision.
              </h2>
              <div className="h-1 w-16 bg-[#E1702C] mb-6" />
              <div className="space-y-4 text-gray-700 leading-relaxed text-sm md:text-base font-light">
                <p>Renés-Cartes is an international, multidisciplinary consultancy firm established to address the evolving complexities of the global energy and infrastructure landscape.
                </p>
                <p>
                  Our unique dual-presence in the UK and Nigeria enables us to provide world-class technical expertise enriched by deep regional insight, ensuring that our clients achieve both operational excellence and sustainable impact.
                </p>
              </div>
              <div className="mt-8 grid grid-cols-2 gap-4 md:gap-8">
                <div className="border-l-4 border-[#123057] pl-4 py-1">
                  <div className="text-2xl md:text-3xl font-bold text-[#123057]">15+</div>
                  <div className="text-[9px] text-gray-500 uppercase tracking-widest mt-1 font-bold">Years Industry Authority</div>
                </div>
                <div className="border-l-4 border-[#E1702C] pl-4 py-1">
                  <div className="text-2xl md:text-3xl font-bold text-[#123057]">Presence</div>
                  <div className="text-[9px] text-gray-500 uppercase tracking-widest mt-1 font-bold">UK & NIGERIA</div>
                </div>
              </div>
            </div>
            <div className="lg:col-span-7 relative group order-1 lg:order-2">
              <div className="aspect-[4/5] md:aspect-[16/9] lg:aspect-[4/5] relative overflow-hidden">
                <Image
                  src="https://images.unsplash.com/photo-1557804506-669a67965ba0?q=80&w=2070&auto=format&fit=crop"
                  alt="Professional Consultation and Strategic Planning"
                  fill
                  className="object-cover group-hover:scale-105 transition-all duration-1000" />

              </div>
              <div className="absolute -bottom-6 -left-6 bg-[#123057] p-8 text-white max-w-xs hidden xl:block shadow-2xl">
                <p className="text-lg font-light italic leading-relaxed">
                  "Technical excellence is not just our standard; it is the foundation of our delivery."
                </p>
                <p className="mt-4 text-[10px] font-bold uppercase tracking-widest text-[#E1702C]">Renés-Cartes Leadership</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Service Clusters */}
      <section className="py-8 md:py-12 bg-gray-50 border-y border-gray-100">
        <div className="corporate-container">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 md:mb-16 gap-6">
            <div className="max-w-2xl">
              <p className="section-title">Expertise Clusters</p>
              <h2 className="section-heading mb-0 text-2xl md:text-4xl">Multidisciplinary Solutions for Global Industry Leaders</h2>
            </div>
            <Button asChild variant="outline" className="border-[#123057] text-[#123057] hover:bg-[#123057] hover:text-white rounded-full font-bold uppercase tracking-widest px-8 py-4 h-auto text-xs transition-all duration-300 hover:-translate-y-1 shadow-[0_4px_14px_rgba(18,48,87,0.1)] hover:shadow-[0_6px_20px_rgba(18,48,87,0.15)]">
              <Link href="/services">Full Service Portfolio</Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-gray-200 border border-gray-200">
            {services.map((service, idx) =>
            <motion.div
              key={service.title}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white p-6 md:p-10 hover:bg-[#123057] group transition-all duration-500 flex flex-col h-full relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-gray-50 group-hover:bg-white/5 rounded-bl-full transition-colors -mr-12 -mt-12" />

                <div className="mb-6 md:mb-8 text-[#E1702C] group-hover:text-white transition-colors relative z-10">
                  <service.icon size={40} strokeWidth={1} />
                </div>
                <h4 className="text-lg font-bold text-[#123057] group-hover:text-white mb-3 md:mb-4 uppercase tracking-tight transition-colors relative z-10">
                  {service.title}
                </h4>
                <p className="text-gray-600 group-hover:text-gray-300 mb-6 md:mb-8 text-[13px] leading-relaxed transition-colors flex-grow font-light relative z-10">
                  {service.description}
                </p>
                <Link
                href={service.href}
                className="inline-flex items-center text-[10px] font-bold text-[#E1702C] uppercase tracking-[0.2em] group-hover:text-white transition-colors relative z-10">

                  Technical Scope <ArrowRight size={12} className="ml-2" />
                </Link>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* Strategic Sectors */}
      <section className="py-8 md:py-12 bg-[#123057] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-white/5 skew-x-12 translate-x-1/2" />
        <div className="corporate-container relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
            <div>
              <p className="section-title text-[#E1702C]">Sectors of Impact</p>
              <h2 className="section-heading text-white text-2xl md:text-4xl">Versatility Across Strategic Global Industries</h2>
              <p className="text-gray-400 text-sm md:text-base leading-relaxed mb-8 md:mb-10 font-light">
                We navigate the regulatory and operational complexities of diverse sectors, providing tailored consultancy that aligns technical requirements with organisational objectives.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 md:gap-y-4 gap-x-8">
                {sectors.map((sector) =>
                <div key={sector} className="flex items-center gap-3 group">
                    <div className="w-1.5 h-1.5 bg-[#E1702C] rounded-full group-hover:scale-125 transition-transform" />
                    <span className="text-white text-[10px] md:text-[11px] font-bold uppercase tracking-widest border-b border-white/0 group-hover:border-white/20 transition-all py-1">
                      {sector}
                    </span>
                  </div>
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 md:gap-4 relative">
              <div className="aspect-square relative overflow-hidden shadow-2xl rounded-2xl group">
                <Image
src="https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?q=80&w=2070&auto=format&fit=crop"
                    alt="Energy and Renewables Sector"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-700" />

              </div>
              <div className="aspect-square relative overflow-hidden mt-6 md:mt-8 shadow-2xl rounded-2xl group">
                <Image
                  src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?q=80&w=2070&auto=format&fit=crop"
                  alt="BIM and Digital Engineering"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-700" />

              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Methodology/Values */}
      <section className="py-8 md:py-12 bg-white">
        <div className="corporate-container text-center max-w-3xl mx-auto">
          <p className="section-title">Our Methodology</p>
          <h2 className="section-heading text-2xl md:text-4xl">Data-Driven, Research-Informed, Outcome-Oriented</h2>
          <p className="text-gray-600 text-sm md:text-base leading-relaxed mb-10 md:mb-12 font-light">
            Our approach integrates rigorous academic research with practical industrial experience, ensuring that every recommendation is both theoretically sound and operationally viable.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            {[
            { title: "Integrity", desc: "Unwavering commitment to ethical standards and technical honesty.", icon: ShieldCheck },
            { title: "Innovation", desc: "Practical application of emerging technologies to solve age-old problems.", icon: Lightbulb },
            { title: "Impact", desc: "Measurable results that drive long-term sustainability and growth.", icon: Activity }].
            map((value) =>
            <div key={value.title} className="flex flex-col items-center group">
                <div className="w-16 h-16 bg-gray-50 group-hover:bg-[#123057] group-hover:text-white rounded-2xl flex items-center justify-center mb-6 text-[#123057] transition-all duration-300 shadow-sm group-hover:shadow-xl group-hover:-translate-y-2">
                  <value.icon size={32} strokeWidth={1} />
                </div>
                <h4 className="text-base font-bold text-[#123057] uppercase tracking-wider mb-2">{value.title}</h4>
                <p className="text-[12px] text-gray-500 leading-relaxed font-light">{value.desc}</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-8 md:py-12 bg-[#E1702C] relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black/10 to-transparent pointer-events-none" />
        <div className="corporate-container relative z-10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-10">
            <div className="text-white max-w-xl text-center lg:text-left">
              <h2 className="text-2xl md:text-4xl font-bold uppercase tracking-tight mb-4">Ready to Resolve Your Complex Challenges?</h2>
              <p className="text-white/80 text-base font-light">
                Partner with Renés-Cartes to bring world-class technical excellence to your strategic operations.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 lg:w-auto">
              <Button asChild className="bg-[#123057] hover:bg-[#0A1D36] text-white px-10 md:px-12 py-5 md:py-6 text-base md:text-lg rounded-full h-auto font-bold uppercase tracking-widest shadow-[0_20px_40px_rgba(0,0,0,0.2)] w-full sm:w-auto transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_25px_50px_rgba(18,48,87,0.4)]">
                <Link href="/engage">Engage Our Experts</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>);

}