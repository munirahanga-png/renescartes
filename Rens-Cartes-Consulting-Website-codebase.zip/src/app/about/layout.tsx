import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About Us | Renés-Cartes Consulting",
  description: "Learn about Renés-Cartes, a UK-based international multidisciplinary consultancy firm working in partnership with Nigerian affiliates.",
};

export default function AboutLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
