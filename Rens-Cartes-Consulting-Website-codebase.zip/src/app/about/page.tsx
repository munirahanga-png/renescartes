"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import Marquee from "react-fast-marquee";
import { Users, CheckCircle2, Globe, Building2, Zap, GraduationCap, HardHat } from "lucide-react";

const partners = [
  "Outsource Global",
  "Primegauge Solutions",
  "Dallitech",
  "NASENI",
  "NGIC",
  "TCN",
  "NISO",
  "Federal Mortgage Bank"
];

const sectorExperience = [
{
  sector: "Oil & Gas",
  focus: "HSEQ Management, Risk Assessment, and Operational Efficiency for major international energy firms.",
  icon: Zap
},
{
  sector: "Renewable Energy",
  focus: "Strategic feasibility and implementation of solar, wind, and hybrid systems for rural and industrial electrification.",
  icon: Globe
},
{
  sector: "Public Infrastructure",
  focus: "BIM implementation, large-scale project oversight, and novel procurement methods for public works.",
  icon: Building2
},
{
  sector: "Higher Education",
  focus: "Global recruitment strategies, academic-industry collaboration, and institutional capacity building.",
  icon: GraduationCap
},
{
  sector: "Construction & Engineering",
  focus: "Digital engineering, structural asset management, and technical supervision of capital projects.",
  icon: HardHat
},
{
  sector: "Consulting",
  focus: "Strategic advisory, organisational transformation, and bespoke consultancy services across public and private sector clients.",
  icon: Users
}];


const trackRecord = [
{ project: "Environmental Impact Assessment", client: "Major Oil Company", year: "2019" },
{ project: "Organisational Restructuring Consultancy", client: "State Owned Enterprises", year: "2015" },
{ project: "BIM Implementation Strategy", client: "Major Construction Project", year: "2020" },
{ project: "Renewable Energy Feasibility", client: "Energy Services Company", year: "2018" }];


export default function AboutPage() {
  return (
    <div className="flex flex-col">
        {/* Hero */}
        <section className="bg-[#123057] py-8 text-white relative">
          <div className="corporate-container relative z-10">
            <h1 className="text-[#E1702C] text-4xl md:text-5xl font-bold uppercase tracking-tight whitespace-nowrap text-center">
              Strategy, Result & Impact.
            </h1>
          </div>
        </section>

        {/* Mission & Vision */}
        <section className="py-12 md:py-16 bg-white">
          <div className="corporate-container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 md:gap-24 items-center">
              <div>
                <p className="section-title">Our Identity</p>
                <h2 className="section-heading">Who We Are & What We Do</h2>
                <div className="space-y-6 text-gray-700 leading-relaxed text-base md:text-lg">
                  <p>We are an international multi-disciplinary consultancy firm with operations in the United Kingdom and Nigeria, from where we serve a global clientele. We offer unique value to our clients by helping them achieve more efficient, cost-effective, innovative, and sustainable organisations.</p>
                  <p>From conceptual design to delivery of bespoke interventions, we develop high-impact, outside-the-box solutions that improve organisational performance and resilience, ensure quality execution of major projects and infrastructure. We provide technical advice that improves production and strategic advice that enhances environmental response.</p>
                </div>
              </div>
              <div className="relative">
                <div className="aspect-video relative overflow-hidden shadow-2xl">
                  <Image
                    src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?q=80&w=2070&auto=format&fit=crop"
                    alt="Modern Corporate Environment"
                    fill
                    className="object-cover !w-full !h-[436px] !max-w-full" />
                </div>
                <div className="absolute -bottom-8 -right-8 bg-[#E1702C] p-8 text-white hidden md:block">
                  <p className="text-4xl font-bold">15+</p>
                  <p className="text-xs uppercase tracking-widest font-bold">Years of Global Authority</p>
                </div>
              </div>
            </div>
          </div>
        </section>

      {/* Dual Presence */}
      <section className="py-12 md:py-16 bg-white">
        <div className="corporate-container">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
                <div className="lg:col-span-7">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="aspect-square relative overflow-hidden transition-all duration-500 hover:scale-105">
                          <Image
                    src="https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?q=80&w=2070&auto=format&fit=crop"
                    alt="United Kingdom Strategic Presence"
                    fill
                    className="object-cover" />

                          <div className="absolute inset-0 bg-[#123057]/40 flex items-center justify-center">
                            <span className="text-white font-bold uppercase tracking-[0.3em] text-sm">United Kingdom</span>
                          </div>
                        </div>
                        <div className="aspect-square relative overflow-hidden mt-12 transition-all duration-500 hover:scale-105">
                          <Image
                    src="https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?q=80&w=2070&auto=format&fit=crop"
                    alt="Nigeria"
                    fill
                    className="object-cover" />

                          <div className="absolute inset-0 bg-[#E1702C]/40 flex items-center justify-center">
                            <span className="text-white font-bold uppercase tracking-[0.3em] text-sm">Nigeria</span>
                          </div>
                        </div>
                  </div>
                </div>
            <div className="lg:col-span-5">
              <p className="section-title">Strategic Presence</p>
              <h2 className="section-heading">Bridging Continents</h2>
              <p className="text-gray-700 leading-relaxed mb-8">
                With a head office in Coventry, UK, and a strategic operations hub in Abuja, Nigeria, 
                Renés-Cartes is uniquely positioned to bridge international technical standards with deep local market insights.
              </p>
              <p className="text-gray-700 leading-relaxed">
                  Our team draws on a local and international network of experts, utilising the latest innovative 
                  techniques and digital technology tools to deliver world-class interventions across both regions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Experience & Track Record */}
      <section className="py-12 md:py-16 bg-white">
        <div className="corporate-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 md:gap-20 items-center">
            <div>
              <p className="section-title">Our Track Record</p>
              <h2 className="section-heading">Multidisciplinary Excellence</h2>
              <div className="space-y-6 text-gray-700 leading-relaxed text-base md:text-lg">
                <p>
                  Through our years of experience and involvement in innovative research projects such as European Union 
                  Framework 7 and Horizon 2020, our team has developed unmatched depth in technical delivery.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 pt-4">
                  {[
                  "National Energy Policy Advisory",
                  "Tier-1 Oil & Gas HSEQ Frameworks",
                  "BIM Implementation Strategy",
                  "International Education Benchmarking",
                    "Asset Optimisation Studies",
                    "Digital Transformation Consulting"].
                    map((item) =>
                  <div key={item} className="flex items-center gap-3">
                      <CheckCircle2 className="text-[#E1702C] shrink-0" size={18} />
                      <span className="text-xs font-bold text-[#123057] uppercase tracking-wide">{item}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="relative aspect-video shadow-2xl overflow-hidden group">
              <Image
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2070&auto=format&fit=crop"
                alt="Global Engineering Project Delivery"
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-1000" />

            </div>
          </div>
        </div>
      </section>

        {/* Sectors Served */}
        <section className="py-12 bg-gray-50 border-y border-gray-100">
          <div className="corporate-container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <p className="section-title">Sectors Served</p>
              <h2 className="section-heading">A Global Perspective on Industry Challenges</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {sectorExperience.map((item, idx) =>
              <motion.div
                key={item.sector}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white p-10 border border-gray-200 hover:border-[#123057] transition-all">

                  <item.icon className="text-[#E1702C] mb-6" size={40} strokeWidth={1.5} />
                  <h4 className="text-xl font-bold text-[#123057] uppercase tracking-tight mb-4">{item.sector}</h4>
                  <p className="text-gray-600 text-sm leading-relaxed">{item.focus}</p>
                </motion.div>
              )}
            </div>
          </div>
        </section>

        {/* Partners Marquee */}
        <section className="py-16 bg-white overflow-hidden">
          <div className="corporate-container mb-12">
             <div className="flex flex-col items-center">
                <p className="section-title">Global Partnerships</p>
                <h2 className="section-heading text-center">Trusted By Industry Leaders</h2>
             </div>
          </div>
          <div className="relative">
            <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none" />
            <Marquee gradient={false} speed={50} pauseOnHover={true}>
              {partners.map((partner) => (
                <div key={partner} className="mx-16 flex items-center justify-center">
                  <span className="text-2xl md:text-3xl font-bold text-[#E1702C] hover:text-[#123057] transition-colors cursor-default whitespace-nowrap uppercase tracking-tighter">
                    {partner}
                  </span>
                </div>
              ))}
            </Marquee>
          </div>
        </section>

        {/* Project Exemplars */}
        <section className="py-12 bg-white">
        <div className="corporate-container">
          <h3 className="text-2xl font-bold text-[#123057] uppercase tracking-widest mb-10 border-b border-gray-100 pb-6">
            Project Exemplars
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b-2 border-[#123057]">
                  <th className="py-6 text-sm font-bold uppercase tracking-widest text-gray-500">Core Service / Project</th>
                  <th className="py-6 text-sm font-bold uppercase tracking-widest text-gray-500">Sector / Client Type</th>
                  <th className="py-6 text-sm font-bold uppercase tracking-widest text-gray-500 text-right">Activity Period</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {trackRecord.map((track, idx) =>
                <tr key={idx} className="group hover:bg-gray-50 transition-colors">
                    <td className="py-6 font-bold text-[#123057] uppercase text-sm">{track.project}</td>
                    <td className="py-6 text-gray-600 text-sm">{track.client}</td>
                    <td className="py-6 text-gray-500 text-sm text-right font-mono">{track.year}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>);

}