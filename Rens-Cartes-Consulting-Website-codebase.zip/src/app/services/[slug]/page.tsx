import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import { servicesData } from "@/lib/services-data";
import { Button } from "@/components/ui/button";

interface PageProps {
  params: { slug: string };
}

export async function generateMetadata({ params }: PageProps) {
  const service = servicesData.find((s) => s.slug === params.slug);
  if (!service) return { title: "Service Not Found" };
  
  return {
    title: `${service.title} | Renés-Cartes Consulting`,
    description: service.description,
  };
}

export default function ServiceDetailPage({ params }: PageProps) {
  const service = servicesData.find((s) => s.slug === params.slug);

  if (!service) {
    notFound();
  }

  return (
    <div className="flex flex-col">
      {/* Service Header */}
      <section className="bg-[#123057] py-24 text-white relative overflow-hidden">
        {service.imageUrl && (
          <div className="absolute inset-0 z-0 opacity-20">
            <img 
              src={service.imageUrl} 
              alt={service.title}
              className="w-full h-full object-cover"
            />
          </div>
        )}
        <div className="corporate-container relative z-10">
          <Link 
            href="/services" 
            className="inline-flex items-center text-xs font-bold uppercase tracking-widest text-[#E1702C] mb-8 hover:text-white transition-colors"
          >
            <ArrowLeft size={16} className="mr-2" /> All Services
          </Link>
          <div className="max-w-4xl">
            <div className="mb-6">
              <service.icon size={48} className="text-[#E1702C]" strokeWidth={1.5} />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold uppercase tracking-tight mb-8">
              {service.title}
            </h1>
            <p className="text-xl text-gray-300 font-light leading-relaxed">
              {service.description}
            </p>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-24 bg-white">
        <div className="corporate-container">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-20">
            {/* Main Content */}
            <div className="lg:col-span-8">
              <div className="mb-16">
                <h2 className="text-2xl font-bold text-[#123057] uppercase tracking-wider mb-8 border-b border-gray-100 pb-4">
                  What We Do
                </h2>
                <p className="text-gray-700 text-lg leading-relaxed mb-6">
                  {service.content.overview}
                </p>
              </div>

              <div className="mb-16">
                <h2 className="text-2xl font-bold text-[#123057] uppercase tracking-wider mb-8 border-b border-gray-100 pb-4">
                  Our Capabilities
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {service.content.capabilities.map((cap, idx) => (
                    <div key={idx} className="flex items-start gap-4 p-4 bg-gray-50 border-l-4 border-[#123057]">
                      <CheckCircle2 size={20} className="text-[#E1702C] shrink-0 mt-1" />
                      <span className="text-gray-700 font-medium text-sm leading-snug">{cap}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-[#123057] uppercase tracking-wider mb-8 border-b border-gray-100 pb-4">
                  Strategic Impact
                </h2>
                <div className="bg-[#123057] p-10 text-white">
                  <p className="text-lg font-light leading-relaxed italic">
                    "{service.content.strategicImpact}"
                  </p>
                </div>
              </div>
            </div>

            {/* Sidebar CTA */}
            <div className="lg:col-span-4">
              <div className="sticky top-32 space-y-8">
                <div className="bg-gray-50 p-10 border border-gray-100">
                  <h4 className="text-xl font-bold text-[#123057] uppercase tracking-tight mb-6">
                    Request a Technical Consultation
                  </h4>
                  <p className="text-gray-600 text-sm leading-relaxed mb-8">
                    Discuss your project requirements with our specialized consultants and discover how we can drive efficiency in your operations.
                  </p>
                  <Button asChild className="w-full bg-[#E1702C] hover:bg-[#C95E1F] text-white py-6 rounded-none font-bold uppercase tracking-widest h-auto">
                    <Link href="/engage">Engage Our Experts</Link>
                  </Button>
                </div>

                <div className="p-10 border border-[#123057]/10">
                  <h4 className="text-sm font-bold text-[#123057] uppercase tracking-widest mb-6">Related Sectors</h4>
                  <ul className="space-y-3">
                    {["Public Infrastructure", "Energy & Renewables", "Oil & Gas", "Enterprise Risk"].map((sector) => (
                      <li key={sector} className="text-sm text-gray-500 flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-[#E1702C]" /> {sector}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
