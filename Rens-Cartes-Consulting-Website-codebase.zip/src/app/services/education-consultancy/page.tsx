"use client";

import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import {
  Search,
  Users,
  Building,
  Monitor,
  ChevronRight,
  Clock,
  BarChart3,
  Shield,
  GraduationCap,
  Briefcase,
  Globe,
  Award,
  Target,
  BookOpen,
  Lightbulb,
  TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const featuredCourses = [
  {
    title: "Leadership & Business Management",
    description: "Develop skills to lead teams and drive organisational success",
    icon: Briefcase,
  },
  {
    title: "Human Resource Management and Talent Development",
    description: "Master the art of talent acquisition and employee development",
    icon: Users,
  },
  {
    title: "Data Analytics and Business Intelligence",
    description: "Turn data into actionable insights for business growth",
    icon: BarChart3,
  },
  {
    title: "Governance, Risk & Compliance",
    description: "Comprehensive training for regulatory compliance professionals",
    icon: Shield,
  },
];

const popularCourses = [
  {
    title: "Strategic Leadership",
    description: "Learn how to develop and execute successful business strategies.",
    duration: "1 week",
    level: "Advanced",
  },
  {
    title: "HR Analytics",
    description: "Use data to make informed decisions about human resources.",
    duration: "2 weeks",
    level: "Intermediate",
  },
  {
    title: "Data Visualisation",
    description: "Create compelling visual representations of complex data.",
    duration: "1 week",
    level: "Beginner",
  },
];

const trainingFormats = [
  {
    title: "Classroom Training",
    description: "Expert-led sessions at premium venues across the UK and Nigeria",
    icon: Building,
  },
  {
    title: "Online Training",
    description: "Flexible digital learning delivered at a pace to suit your requirements",
    icon: Monitor,
  },
  {
    title: "In-House Training",
    description:       "Customised programs delivered at your organisation's facilities",
    icon: Users,
  },
];

const courseCategories = [
  "Banking, Insurance and Financial Services",
  "Communication and Writing Skills",
  "Customer Service",
  "Data Analytics and Business Intelligence",
  "Digital Transformation and Innovation",
  "Energy Transition and Renewable Energy",
  "Financial Management and Accounting",
  "Governance, Risk and Compliance",
  "Health, Safety and Environment",
  "Human Resource Management and Talent Development",
  "Information Technology and Digital Systems",
  "IT Management and Cyber Security",
  "Leadership and Business Management",
  "Legal and Contracts Management",
  "Maintenance and Engineering",
  "Office Administration and Executive Support",
  "Oil and Gas Technology",
  "Operational Auditing and Quality Assurance",
  "Personal Effectiveness and Self Development",
  "Project and Program Management",
  "Public Relations",
  "Risk and Crisis Management",
  "Sales and Marketing",
  "Security Operations and Risk Protection",
  "Strategy and Strategic Planning",
  "Supply Chain Management and Procurement",
];

const venues = [
  { city: "London", country: "UK" },
  { city: "Lagos", country: "Nigeria" },
  { city: "Abuja", country: "Nigeria" },
  { city: "Manchester", country: "UK" },
  { city: "Port Harcourt", country: "Nigeria" },
  { city: "Edinburgh", country: "UK" },
];

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const whyChooseUs = [
  {
    title: "Industry Expertise",
    description: "Our trainers bring decades of real-world experience from energy, infrastructure, and corporate sectors.",
    icon: Award,
  },
  {
    title: "Global Reach",
    description: "Training programs delivered across the UK and Nigeria with consistent quality standards.",
    icon: Globe,
  },
  {
    title: "Tailored Solutions",
    description:       "Customised curricula designed to address your organisation's specific challenges and goals.",
    icon: Target,
  },
  {
    title: "Practical Approach",
    description: "Hands-on learning methodologies that translate directly into workplace performance.",
    icon: Lightbulb,
  },
];

export default function EducationConsultancyPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [selectedVenue, setSelectedVenue] = useState("All Venues");
  const [selectedDuration, setSelectedDuration] = useState("Any Duration");

  return (
    <div className="flex flex-col bg-white">
      <section className="relative py-24 md:py-32 bg-[#123057] overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="https://images.unsplash.com/photo-1524178232363-1fb2b075b655?q=80&w=2070&auto=format&fit=crop"
            alt="Education and Training"
            fill
            className="object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-[#123057] via-[#123057]/95 to-[#1a4a7a]/90" />
        </div>
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-[#E1702C] rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-500 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
        </div>
        
        <div className="corporate-container relative z-10">
          <div className="max-w-3xl">
            <motion.div
              initial="initial"
              animate="animate"
              variants={fadeIn}
            >
              <div className="inline-block px-3 py-1 border border-[#E1702C]/50 text-[#E1702C] text-[9px] md:text-xs font-bold uppercase tracking-[0.3em] mb-6">
                Education Consultancy
              </div>
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-white mb-6 uppercase tracking-tight">
                Professional Development <br />
                <span className="text-white/60">& Training Excellence</span>
              </h1>
              <p className="text-gray-300 text-lg max-w-2xl mb-8">
                Empowering organisations with world-class training solutions designed to develop talent, enhance capabilities, and drive sustainable growth across the UK and Nigeria.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild className="bg-gradient-to-r from-[#E1702C] to-[#C95E1F] hover:from-[#C95E1F] hover:to-[#B04D18] text-white px-8 py-4 text-sm rounded-full h-auto font-bold uppercase tracking-wider">
                  <Link href="/contact">Request Training</Link>
                </Button>
                <Button asChild variant="outline" className="bg-white/10 backdrop-blur-md border-white/40 text-white hover:bg-white hover:text-[#123057] px-8 py-4 text-sm rounded-full h-auto font-bold uppercase tracking-wider border-2">
                  <Link href="/experience">Browse Courses</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 bg-white">
        <div className="corporate-container">
          <div className="text-center mb-12">
            <p className="section-title">Why Choose Us</p>
            <h2 className="text-2xl md:text-4xl font-bold text-[#123057] mb-4">
              The Renés-Cartes Advantage
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyChooseUs.map((item, idx) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="text-center group"
              >
                <div className="w-16 h-16 bg-gray-50 group-hover:bg-[#123057] rounded-2xl flex items-center justify-center mx-auto mb-4 text-[#E1702C] group-hover:text-white transition-all duration-300 shadow-sm group-hover:shadow-xl group-hover:-translate-y-2">
                  <item.icon size={32} strokeWidth={1.5} />
                </div>
                <h3 className="text-lg font-bold text-[#123057] mb-2">{item.title}</h3>
                <p className="text-gray-600 text-sm">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="corporate-container">
          <div className="text-center mb-12">
            <p className="section-title">Featured Programs</p>
            <h2 className="text-2xl md:text-4xl font-bold text-[#123057] mb-4">
              Core Training Areas
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredCourses.map((course, idx) => (
              <motion.div
                key={course.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 group cursor-pointer"
              >
                <div className="w-14 h-14 bg-gradient-to-br from-[#123057] to-[#1a4a7a] rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <course.icon size={28} className="text-white" />
                </div>
                <h3 className="text-lg font-bold text-[#123057] mb-2">{course.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{course.description}</p>
                <span className="inline-flex items-center text-[#E1702C] text-sm font-semibold group-hover:gap-2 transition-all">
                  Learn More <ChevronRight size={16} />
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="courses" className="py-16 md:py-20 bg-white">
        <div className="corporate-container">
          <div className="text-center mb-12">
            <p className="section-title">Course Finder</p>
            <h2 className="text-2xl md:text-4xl font-bold text-[#123057] mb-4">Find Your Perfect Course</h2>
          </div>
          
          <div className="bg-gray-50 p-6 rounded-2xl mb-8">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 relative">
                <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search for courses, topics..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#123057] focus:border-transparent"
                />
              </div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#123057] bg-white"
              >
                <option>All Categories</option>
                {courseCategories.slice(0, 10).map((cat) => (
                  <option key={cat}>{cat}</option>
                ))}
              </select>
              <select
                value={selectedVenue}
                onChange={(e) => setSelectedVenue(e.target.value)}
                className="px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#123057] bg-white"
              >
                <option>All Venues</option>
                {venues.map((v) => (
                  <option key={v.city}>{v.city}, {v.country}</option>
                ))}
              </select>
              <select
                value={selectedDuration}
                onChange={(e) => setSelectedDuration(e.target.value)}
                className="px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#123057] bg-white"
              >
                <option>Any Duration</option>
                <option>1 week</option>
                <option>2 weeks</option>
                <option>3 weeks</option>
                <option>4+ weeks</option>
              </select>
              <Button className="bg-[#E1702C] hover:bg-[#C95E1F] text-white px-8 py-3 h-auto rounded-lg font-semibold">
                Search
              </Button>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold text-[#123057] mb-6">Popular Courses</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {popularCourses.map((course, idx) => (
                <motion.div
                  key={course.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-white p-6 rounded-xl border border-gray-200 hover:border-[#E1702C] hover:shadow-lg transition-all duration-300"
                >
                  <h4 className="text-lg font-bold text-[#123057] mb-2">{course.title}</h4>
                  <p className="text-gray-600 text-sm mb-4">{course.description}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="flex items-center gap-1 text-gray-500">
                      <Clock size={14} />
                      {course.duration}
                    </span>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      course.level === "Advanced" ? "bg-red-100 text-red-700" :
                      course.level === "Intermediate" ? "bg-yellow-100 text-yellow-700" :
                      "bg-green-100 text-green-700"
                    }`}>
                      {course.level}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 bg-[#123057]">
        <div className="corporate-container">
          <div className="text-center mb-12">
            <p className="section-title text-[#E1702C]">Delivery Options</p>
            <h2 className="text-2xl md:text-4xl font-bold text-white mb-4">
              Flexible Training Formats
            </h2>
            <p className="text-gray-300">Designed to suit your organisational requirements</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {trainingFormats.map((format, idx) => (
              <motion.div
                key={format.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white/10 backdrop-blur-sm p-8 rounded-2xl text-center hover:bg-white/20 transition-all duration-300"
              >
                <div className="w-16 h-16 bg-[#E1702C] rounded-full flex items-center justify-center mx-auto mb-6">
                  <format.icon size={32} className="text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{format.title}</h3>
                <p className="text-gray-300 text-sm">{format.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 bg-gray-50">
        <div className="corporate-container">
          <div className="text-center mb-12">
            <p className="section-title">Specialisations</p>
            <h2 className="text-2xl md:text-4xl font-bold text-[#123057] mb-4">
              Explore Our Course Categories
            </h2>
            <p className="text-gray-600">Find the right training for your team</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {courseCategories.map((category, idx) => (
              <motion.button
                key={category}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.02 }}
                className="p-4 bg-white rounded-lg text-left text-sm text-gray-700 hover:bg-[#123057] hover:text-white transition-all duration-300 border border-gray-100 shadow-sm"
              >
                {category}
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 bg-white">
        <div className="corporate-container">
          <div className="text-center mb-12">
            <p className="section-title">Locations</p>
            <h2 className="text-2xl md:text-4xl font-bold text-[#123057] mb-4">
              Training Venues
            </h2>
            <p className="text-gray-600">We deliver training across the UK and Nigeria</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {venues.map((venue, idx) => (
              <motion.div
                key={venue.city}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-gray-50 p-6 rounded-xl text-center hover:bg-[#123057] group transition-all duration-300 cursor-pointer"
              >
                <div className="w-12 h-12 bg-[#E1702C]/10 group-hover:bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3 transition-colors">
                  <Globe size={24} className="text-[#E1702C] group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-[#123057] group-hover:text-white font-bold text-lg transition-colors">{venue.city}</h3>
                <p className="text-gray-500 group-hover:text-gray-300 text-sm transition-colors">{venue.country}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 bg-[#E1702C]">
        <div className="corporate-container">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="text-white text-center lg:text-left max-w-xl">
              <h2 className="text-2xl md:text-4xl font-bold mb-4">Ready to Enhance Your Team&apos;s Capabilities?</h2>
              <p className="text-white/80 text-lg">Contact Renés-Cartes today to discuss your training requirements and discover how we can help your organisation thrive.</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild className="bg-[#123057] hover:bg-[#0A1D36] text-white px-10 py-5 h-auto rounded-full font-bold uppercase tracking-wider shadow-[0_20px_40px_rgba(0,0,0,0.2)]">
                <Link href="/contact">Contact Us</Link>
              </Button>
              <Button asChild variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-[#E1702C] px-10 py-5 h-auto rounded-full font-bold uppercase tracking-wider bg-transparent">
                <Link href="/services">View All Services</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
