import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { servicesData } from "@/lib/services-data";
import { Button } from "@/components/ui/button";

export const metadata = {
  title: "Professional Services | Renés-Cartes Consultancy",
  description: "Explore our multidisciplinary technical and management consultancy services across energy, education, and digital engineering."
};

export default function ServicesPage() {
  return (
    <div className="flex flex-col">
    {/* Header */}
    <section className="bg-[#123057] pt-12 pb-8 md:pb-12 text-white relative overflow-hidden">
      <div className="corporate-container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold uppercase tracking-tight mb-8 text-[#E1702C]">OUR CAPABILITIES</h1>
          <p className="text-xl text-gray-300 leading-relaxed font-light">
            Renés-Cartes provides high-impact technical expertise and strategic management solutions
            designed to improve organisational performance and resilience in a complex global environment.
          </p>
        </div>
      </div>
      <div className="absolute top-0 right-0 w-1/3 h-full bg-white/5 skew-x-12 translate-x-1/2" />
    </section>

    {/* Services Grid */}
    <section className="py-10 md:py-14 bg-white">
      <div className="corporate-container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {servicesData.map((service) =>
          <div
            key={service.slug}
            className="group border border-gray-100 p-10 hover:border-[#123057] transition-all duration-500 flex flex-col h-full bg-gray-50/30">

              <div className="mb-8 text-[#123057] group-hover:text-[#E1702C] transition-colors">
                <service.icon size={44} strokeWidth={1.5} />
              </div>
              <h3 className="text-xl font-bold text-[#123057] mb-4 uppercase tracking-tight leading-tight">
                {service.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed mb-10 flex-grow">
                {service.description}
              </p>
              <Link
              href={`/services/${service.slug}`}
              className="inline-flex items-center text-xs font-bold text-[#123057] uppercase tracking-[0.2em] group-hover:text-[#E1702C] transition-colors">

                Technical Scope <ArrowRight size={14} className="ml-2" />
              </Link>
            </div>
          )}
        </div>
      </div>
    </section>

    {/* Consultation Section */}
    <section className="py-10 md:py-14 bg-gray-50 border-t border-gray-100">
        <div className="corporate-container">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-[#123057] uppercase tracking-tight mb-8">
              Need a Bespoke Solution?
            </h2>
            <p className="text-gray-600 mb-12 text-lg">
              Our team of experts can develop tailored interventions that address your specific organisational challenges.
            </p>
              <Button asChild className="bg-[#123057] hover:bg-[#0A1D36] text-white px-12 py-8 text-lg rounded-full h-auto font-bold uppercase tracking-widest transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl">
                <Link href="/engage">Engage Our Experts</Link>
              </Button>

          </div>
        </div>
      </section>
    </div>);

}