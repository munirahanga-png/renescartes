import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact Us | Renés-Cartes Energy & Management Consulting",
  description: "Connect with our offices in the UK and Nigeria for professional consultancy inquiries.",
};

export default function ContactLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
