"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Mail, Phone, MapPin, Globe, Linkedin } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ContactPage() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
        <section className="bg-[#123057] pt-12 pb-20 relative overflow-hidden">
        <div className="corporate-container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <p className="section-title text-[#E1702C]">Contact Us</p>
            <h1 className="text-4xl md:text-6xl text-white font-bold leading-tight mb-8 uppercase tracking-tight">
              Get In <br />
              <span className="text-white/60">Touch.</span>
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed font-light">
              Reach us at our offices in the United Kingdom and Nigeria, or connect with us via email, phone, or social media.
            </p>
          </motion.div>
        </div>
        <div className="absolute top-0 right-0 w-1/3 h-full bg-white/5 -skew-x-12 translate-x-1/2" />
      </section>

      {/* Contact Content */}
      <section className="py-24 bg-white">
        <div className="corporate-container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
            {/* Offices */}
            <div>
              <p className="section-title">Our Offices</p>
              <h2 className="section-heading mb-12 border-b border-gray-100 pb-4">Where to Find Us</h2>

              <div className="space-y-12">
                <div className="flex gap-6">
                  <div className="w-12 h-12 bg-gray-50 flex items-center justify-center text-[#E1702C] shrink-0">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-[#123057] uppercase tracking-wider mb-2">United Kingdom (HQ)</h4>
                    <p className="text-gray-600 leading-relaxed text-sm">
                      18 Lila Avenue, Coventry<br />
                      CV3 1LW, United Kingdom
                    </p>
                  </div>
                </div>

                <div className="flex gap-6">
                  <div className="w-12 h-12 bg-gray-50 flex items-center justify-center text-[#E1702C] shrink-0">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-[#123057] uppercase tracking-wider mb-2">Nigeria Operations</h4>
                    <p className="text-gray-600 leading-relaxed text-sm">
                      31 Adamu Ciroma Crescent<br />
                      Jabi, FCT-Abuja, Nigeria
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Details & Social */}
            <div className="space-y-16">
              <div>
                <p className="section-title">Direct Channels</p>
                <h2 className="section-heading mb-12 border-b border-gray-100 pb-4">Email & Phone</h2>

                <div className="space-y-8">
                  <a href="mailto:contact@renescartes.com" className="flex items-center gap-6 group">
                    <div className="w-12 h-12 bg-gray-50 flex items-center justify-center text-[#E1702C] group-hover:bg-[#123057] group-hover:text-white transition-all">
                      <Mail size={24} />
                    </div>
                    <span className="text-lg font-bold text-[#123057] border-b border-transparent group-hover:border-[#E1702C] transition-all uppercase tracking-tight">contact@renescartes.com</span>
                  </a>
                  <div className="space-y-4">
                    <a href="tel:+447854217797" className="flex items-center gap-6 group">
                      <div className="w-12 h-12 bg-gray-50 flex items-center justify-center text-[#E1702C] group-hover:bg-[#123057] group-hover:text-white transition-all">
                        <Phone size={24} />
                      </div>
                      <span className="text-lg font-bold text-[#123057] border-b border-transparent group-hover:border-[#E1702C] transition-all uppercase tracking-tight">+44 (0) 785 421 7797</span>
                    </a>
                    <a href="tel:+2348095192297" className="flex items-center gap-6 group pl-[72px]">
                      <span className="text-lg font-bold text-[#123057] border-b border-transparent group-hover:border-[#E1702C] transition-all uppercase tracking-tight">+234 809 519 2297</span>
                    </a>
                  </div>
                </div>
              </div>

              <div>
                <p className="section-title">Connect With Us</p>
                <h2 className="section-heading mb-12 border-b border-gray-100 pb-4">Social Media</h2>

                <div className="space-y-6">
                  <a href="#" className="flex items-center gap-6 group">
                    <div className="w-12 h-12 bg-gray-50 flex items-center justify-center text-[#E1702C] group-hover:bg-[#123057] group-hover:text-white transition-all">
                      <Linkedin size={24} />
                    </div>
                    <span className="text-lg font-bold text-[#123057] border-b border-transparent group-hover:border-[#E1702C] transition-all uppercase tracking-tight">LinkedIn</span>
                  </a>
                  <a href="#" className="flex items-center gap-6 group">
                    <div className="w-12 h-12 bg-gray-50 flex items-center justify-center text-[#E1702C] group-hover:bg-[#123057] group-hover:text-white transition-all">
                      <svg width={24} height={24} viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                    </div>
                    <span className="text-lg font-bold text-[#123057] border-b border-transparent group-hover:border-[#E1702C] transition-all uppercase tracking-tight">X (Twitter)</span>
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* CTA to Engage page */}
          <div className="mt-20 text-center border-t border-gray-100 pt-16">
            <p className="text-gray-500 text-sm uppercase tracking-widest font-bold mb-6">Ready to start a project?</p>
            <Button asChild className="bg-gradient-to-r from-[#E1702C] to-[#C95E1F] hover:from-[#C95E1F] hover:to-[#B04D18] text-white px-10 py-6 text-base rounded-full h-auto font-bold uppercase tracking-wider transition-all duration-300 shadow-[0_10px_30px_rgba(225,112,44,0.3)] hover:shadow-[0_15px_35px_rgba(225,112,44,0.4)] hover:-translate-y-1">
              <Link href="/engage">Engage Our Experts</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Global Connectivity Section */}
      <section className="py-24 bg-[#123057] relative overflow-hidden text-white">
        <div className="absolute inset-0 opacity-10 flex items-center justify-center">
          <Globe size={1000} strokeWidth={0.5} />
        </div>
        <div className="corporate-container relative z-10 text-center max-w-3xl mx-auto">
          <h3 className="text-3xl font-bold uppercase tracking-tight mb-6">World-Class Technical Network</h3>
          <p className="text-gray-400 text-lg font-light leading-relaxed">
            Our dual-presence strategy ensures that your organisation benefits from international engineering standards
            seamlessly integrated with deep regional industrial insight.
          </p>
        </div>
      </section>
    </div>
  );
}
