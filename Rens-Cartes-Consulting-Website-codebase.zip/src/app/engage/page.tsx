"use client";

import { motion } from "framer-motion";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function EngagePage() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="bg-[#123057] pt-12 pb-20 relative overflow-hidden">
        <div className="corporate-container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <p className="section-title text-[#E1702C]">Engage Our Experts</p>
            <h1 className="text-4xl md:text-6xl text-white font-bold leading-tight mb-8 uppercase tracking-tight">
              Start Your <br />
              <span className="text-white/60">Engagement.</span>
            </h1>
            <p className="text-xl text-gray-300 leading-relaxed font-light">
              Tell us about your technical or management consultancy needs and our multi-disciplinary team will respond within 24 business hours.
            </p>
          </motion.div>
        </div>
        <div className="absolute top-0 right-0 w-1/3 h-full bg-white/5 -skew-x-12 translate-x-1/2" />
      </section>

      {/* Engagement Form */}
      <section className="py-24 bg-white">
        <div className="corporate-container max-w-3xl mx-auto">
          <div className="bg-gray-50 p-12 border-t-8 border-[#123057] shadow-xl">
              <h3 className="text-2xl font-bold text-[#123057] uppercase tracking-tight mb-8">Professional Enquiry</h3>
            <form className="space-y-8" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-500">Full Name</label>
                  <input type="text" className="w-full bg-white border border-gray-200 px-4 py-4 focus:outline-none focus:border-[#E1702C] transition-colors" placeholder="e.g. Dr. John Smith" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-500">Professional Email</label>
                  <input type="email" className="w-full bg-white border border-gray-200 px-4 py-4 focus:outline-none focus:border-[#E1702C] transition-colors" placeholder="jsmith@organisation.com" />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-500">Organisation / Entity</label>
                  <input type="text" className="w-full bg-white border border-gray-200 px-4 py-4 focus:outline-none focus:border-[#E1702C] transition-colors" placeholder="Corporate or Government Body" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-gray-500">Primary Sector</label>
                  <select className="w-full bg-white border border-gray-200 px-4 py-4 focus:outline-none focus:border-[#E1702C] transition-colors appearance-none">
                    <option>Energy & Renewables</option>
                    <option>Oil & Gas</option>
                    <option>Education & Research</option>
                    <option>Construction & Engineering</option>
                    <option>Public Infrastructure</option>
                    <option>Strategic Risk</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-gray-500">Technical Scope / Message</label>
                <textarea rows={6} className="w-full bg-white border border-gray-200 px-4 py-4 focus:outline-none focus:border-[#E1702C] transition-colors resize-none" placeholder="Please provide a brief overview of your technical or management consultancy needs..."></textarea>
              </div>
              <Button className="bg-gradient-to-r from-[#123057] to-[#1D4B85] hover:from-[#0A1D36] hover:to-[#123057] text-white px-12 py-8 text-lg rounded-full w-full font-bold uppercase tracking-widest transition-all duration-300 h-auto shadow-[0_20px_40px_rgba(18,48,87,0.2)] hover:shadow-[0_25px_50px_rgba(18,48,87,0.35)] hover:-translate-y-2">
                Submit Engagement Request <Send className="ml-3" size={18} />
              </Button>
              <p className="text-[10px] text-gray-400 text-center uppercase tracking-[0.3em] font-bold">
                Confidential technical review within 24 business hours.
              </p>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}
