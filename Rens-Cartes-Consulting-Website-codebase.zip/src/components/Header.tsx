"use client";

import Link from "next/link";
import Image from "next/image";
import { useState, useEffect } from "react";
import { Menu, X, ChevronDown, Globe } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const navItems = [
{ name: "Home", href: "/" },
{ name: "About Us", href: "/about" },
{
  name: "Services",
  href: "/services",
  children: [
  { name: "Education Consultancy", href: "/services/education-consultancy" },
  { name: "Energy & Environmental", href: "/services/energy-environment" },
  { name: "Renewable Energy", href: "/services/renewable-energy" },
  { name: "BIM & Digital Engineering", href: "/services/bim-digital" },
  { name: "Project Management", href: "/services/project-management" },
  { name: "HSEQ Management", href: "/services/hseq" },
  { name: "Enterprise Risk (ERM)", href: "/services/erm" },
  { name: "Strategic Transformation", href: "/services/transformation" },
  { name: "IT Solutions", href: "/services/it-solutions" },
  { name: "Construction Tech", href: "/services/construction-tech" }]

},
{ name: "Courses & Training", href: "/experience" },
{ name: "Team", href: "/team" },
{ name: "Contact", href: "/contact" }];


export function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 w-full z-50 transition-all duration-300",
          scrolled ? "bg-white shadow-xl py-1" : "bg-white/95 backdrop-blur-sm py-2"
      )}>

        <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6 flex items-center gap-8">
          <Link href="/" className="flex items-center gap-3 group">
                <Image
            src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/project-uploads/b61c2f97-8295-4a85-b7fd-6a54a7750012/Renes_icon-resized-1768836864966.webp?width=200&height=200&resize=contain"
            alt="Renés-Cartes Logo"
            width={38}
            height={38}
            className="group-hover:scale-105 transition-transform duration-300" />

              <div className="flex flex-col">
              <span className="font-bold text-lg leading-none tracking-tighter uppercase text-[#123057]">
                Renés-Cartes
              </span>
              <span className="text-[9px] font-bold opacity-70 uppercase tracking-[0.2em] text-[#E1702C] mt-0.5">CONSULTING
            </span>
            </div>
          </Link>

        {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-5 flex-1">
            {navItems.map((item) =>
            <div key={item.name} className="relative group py-1">
                <Link
                href={item.href}
                className="text-[11px] font-bold uppercase tracking-widest text-[#123057] hover:text-[#E1702C] transition-colors flex items-center gap-1">

                  {item.name}
                  {item.children && <ChevronDown size={12} className="group-hover:rotate-180 transition-transform duration-300" />}
                </Link>
                
                {item.children &&
              <div className="absolute top-full left-0 mt-0 w-72 bg-white shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 border-t-4 border-[#123057] translate-y-2 group-hover:translate-y-0">
                    <div className="py-4">
                      <div className="px-6 py-2 border-b border-gray-50 mb-2">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em]">Our Technical Scope</span>
                      </div>
                      {item.children.map((child) =>
                  <Link
                    key={child.name}
                    href={child.href}
                    className="block px-6 py-2.5 text-[11px] font-bold uppercase tracking-wider text-[#123057] hover:bg-gray-50 hover:text-[#E1702C] transition-all">

                          {child.name}
                        </Link>
                  )}
                      <div className="mt-4 px-6 pt-4 border-t border-gray-50">
                        <Link href="/services" className="text-[10px] font-bold text-[#123057] underline underline-offset-4 hover:text-[#E1702C] uppercase tracking-widest">View All Capabilities</Link>
                      </div>
                    </div>
                  </div>
              }
              </div>
            )}
                <div className="ml-auto flex items-center gap-2">
                  <div className="h-5 w-px bg-gray-200" />
                  <Button asChild className="bg-gradient-to-r from-[#123057] to-[#1D4B85] hover:from-[#E1702C] hover:to-[#C95E1F] text-white rounded-full px-5 py-2 h-auto text-[10px] font-bold uppercase tracking-widest shadow-[0_4px_12px_rgba(18,48,87,0.15)] hover:shadow-[0_8px_20px_rgba(225,112,44,0.35)] transition-all duration-300 hover:-translate-y-0.5">
                    <Link href="/engage">Engage Our Experts</Link>
                  </Button>
                </div>
            </nav>

          {/* Mobile Toggle */}
          <button
            className="lg:hidden p-2 text-[#123057] hover:text-[#E1702C] transition-colors ml-auto"
          onClick={() => setIsOpen(!isOpen)}>

          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <div
        className={cn(
          "lg:hidden absolute top-full left-0 w-full bg-white shadow-2xl transition-all duration-500 ease-in-out overflow-hidden",
          isOpen ? "max-h-screen border-t border-gray-100" : "max-h-0"
        )}>

        <div className="corporate-container py-10 flex flex-col gap-6">
          {navItems.map((item) =>
          <div key={item.name} className="border-b border-gray-50 pb-4">
              <Link
              href={item.href}
              className="text-xl font-bold text-[#123057] uppercase tracking-tight block flex justify-between items-center"
              onClick={() => !item.children && setIsOpen(false)}>

                {item.name}
              </Link>
              {item.children &&
            <div className="grid grid-cols-1 gap-3 mt-4 pl-4 border-l-2 border-gray-100">
                  {item.children.map((child) =>
              <Link
                key={child.name}
                href={child.href}
                className="text-sm font-medium text-gray-500 hover:text-[#E1702C]"
                onClick={() => setIsOpen(false)}>

                      {child.name}
                    </Link>
              )}
                </div>
            }
            </div>
          )}
          <Button asChild className="bg-[#E1702C] hover:bg-[#C95E1F] rounded-none py-8 h-auto text-lg font-bold uppercase tracking-widest mt-4">
            <Link href="/contact" onClick={() => setIsOpen(false)}>
              Engage Our Experts
            </Link>
          </Button>
          <div className="flex items-center justify-center gap-4 text-gray-400 mt-4">
            <Globe size={16} />
            <span className="text-[10px] font-bold uppercase tracking-[0.2em]">UK & Nigeria Presence</span>
          </div>
        </div>
      </div>
    </header>);

}